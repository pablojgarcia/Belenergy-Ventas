#!/usr/bin/env bash
# Dev helper para arrancar/parar el backend local (Git Bash / MSYS2).
#
# Uso (desde Backend/):
#   ./dev.sh start                 mata todo lo que ocupe :8000, carga .env.local,
#                                  levanta uvicorn (--reload) y verifica /health.
#   ./dev.sh start --no-reload     sin recarga automatica.
#   ./dev.sh start --env <file>    archivo de entorno a usar (default .env.local).
#   ./dev.sh stop                  detiene el backend (reloader + worker).
#   ./dev.sh restart               stop + start.
#   ./dev.sh status                PID file, puerto 8000, salud.
#   ./dev.sh logs [N]              tail del uvicorn_local.log (default 50 lineas).
#
# Regla del proyecto:
#   - dev/pruebas SIEMPRE contra .env.local (Postgres local).
#   - Supabase es solo produccion (deploy desde GitHub Actions).

set -u

PORT=8000
HOST=0.0.0.0
ENV_FILE=".env.local"
VENV_PY="$(cd .. && pwd)/venv/Scripts/python.exe"
LOG="$(pwd)/uvicorn_local.log"
PIDFILE="$(pwd)/.uvicorn.pid"
HEALTH_URL="http://127.0.0.1:${PORT}/health"
DEFAULT_ENV="$(pwd)/.env.local"
FALLBACK_ENV="$(cd .. && pwd)/.env"

# --- proceso ---------------------------------------------------------------

pids_on_port() {
  netstat -ano 2>/dev/null \
    | grep -E ":${PORT}[[:space:]]" \
    | grep -i listening \
    | awk '{print $NF}' \
    | grep -E '^[0-9]+$' | sort -u
}

uvicorn_pids() {
  wmic process where "name='python.exe'" get ProcessId,CommandLine /format:list 2>/dev/null \
    | tr -d '\r' \
    | awk -F'=' '
        BEGIN { cmd = "" }
        /^CommandLine=/ { cmd = $0 }
        /^ProcessId=/ {
          if (cmd ~ /uvicorn|app[.]main/) print $2
          cmd = ""
        }' \
    | grep -E '^[0-9]+$' | sort -u
}

kill_all() {
  local pids
  pids="$(pids_on_port; uvicorn_pids)"
  [ -z "$pids" ] && { echo 0; return 0; }
  local count=0
  for pid in $pids; do
    taskkill //T //F //PID "$pid" >/dev/null 2>&1 || true
    count=$((count + 1))
  done
  sleep 1
  echo "$count"
}

_health() {
  curl -sf --max-time 2 "$HEALTH_URL" >/dev/null 2>&1
}

# --- env -------------------------------------------------------------------

load_env() {
  local file="$1"
  [ -f "$file" ] || { echo "ERROR: no existe $file" >&2; exit 1; }
  set -a
  # shellcheck disable=SC1090
  . "$file"
  set +a
}

resolve_env() {
  local file="${ENV_FILE}"
  if [ "$file" = ".env.local" ]; then
    if [ -f "$DEFAULT_ENV" ]; then
      echo "$DEFAULT_ENV"
    elif [ -f "$FALLBACK_ENV" ]; then
      echo "Aviso: no existe $DEFAULT_ENV; uso $FALLBACK_ENV" >&2
      echo "$FALLBACK_ENV"
    else
      echo "ERROR: no encontre $DEFAULT_ENV ni $FALLBACK_ENV" >&2
      exit 1
    fi
  else
    echo "$file"
  fi
}

warn_if_not_local() {
  local url="$1"
  case "$url" in
    *localhost*|*127.0.0.1*) ;;
    *)
      echo "ADVERTENCIA: DATABASE_URL no apunta a Postgres local (localhost)."
      echo "Regla del proyecto: dev/pruebas usan .env.local (Postgres local);"
      echo "Supabase es solo produccion (deploy desde GitHub Actions)."
      ;;
  esac
}

# --- comandos --------------------------------------------------------------

cmd_start() {
  local env_file reload_flag=""
  env_file="$(resolve_env)"
  load_env "$env_file"
  : "${DATABASE_URL:?Falta DATABASE_URL en $env_file}"
  warn_if_not_local "$DATABASE_URL"

  echo "Limpiando procesos en :${PORT} ..."
  local killed
  killed="$(kill_all)"
  [ "$killed" != "0" ] && echo "  procesos terminados: $killed"
  sleep 1

  rm -f "$PIDFILE"

  if [ "${1:-}" = "--no-reload" ]; then
    reload_flag="--no-reload"
  else
    reload_flag="--reload --reload-dir app"
  fi

  # shellcheck disable=SC2086
  nohup "$VENV_PY" -m uvicorn app.main:app --host "$HOST" --port "$PORT" $reload_flag >>"$LOG" 2>&1 &

  echo "Backend iniciado. Log: $LOG"
  echo "Esperando /health ..."
  local i listener_pid
  for i in $(seq 1 30); do
    if _health; then
      for i in $(seq 1 5); do
        listener_pid="$(pids_on_port | head -1)"
        [ -n "$listener_pid" ] && break
        sleep 1
      done
      if [ -n "$listener_pid" ]; then
        echo "$listener_pid" > "$PIDFILE"
        echo "Health OK -> $HEALTH_URL (listener PID $listener_pid, guardado en $PIDFILE)"
      else
        rm -f "$PIDFILE"
        echo "Health OK -> $HEALTH_URL (listener no detectado en netstat)"
      fi
      exit 0
    fi
    sleep 1
  done
  echo "No responde /health. Ultimas lineas del log:"
  cmd_logs 60
  exit 1
}

cmd_stop() {
  local killed
  killed="$(kill_all)"
  rm -f "$PIDFILE"
  if [ "$killed" != "0" ]; then
    echo "Backend detenido (procesos terminados: $killed)"
  else
    echo "No habia backend corriendo."
  fi
}

cmd_restart() {
  cmd_stop
  echo "---"
  cmd_start "${1:-}"
}

cmd_status() {
  local pid_file owners health
  if [ -f "$PIDFILE" ]; then
    pid_file="$(cat "$PIDFILE")"
  else
    pid_file=""
  fi
  owners="$(pids_on_port | tr '\n' ' ')"
  if _health; then health="OK"; else health="no responde"; fi
  echo "PID file: ${pid_file:-'-'}"
  echo "Puerto ${PORT} (LISTENING): ${owners:-'-'}"
  echo "Health: $health"
}

cmd_logs() {
  local n="${1:-50}"
  [ -f "$LOG" ] || { echo "No existe uvicorn_local.log todavia."; return 0; }
  tail -n "$n" "$LOG"
}

case "${1:-start}" in
  start)      shift; cmd_start "${1:-}";;
  stop)       cmd_stop;;
  restart)    shift; cmd_restart "${1:-}";;
  status)     cmd_status;;
  logs)       shift; cmd_logs "${1:-50}";;
  *)
    echo "Uso: ./dev.sh {start|stop|restart|status|logs [N]}"
    exit 2
    ;;
esac
